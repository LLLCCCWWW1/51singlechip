#ifndef __MATRIXKEY_H__
#define __MATRIXKEY_H__
#include "regx52.h"


typedef unsigned char u8;
typedef unsigned int u16;

#define SMG_PORT			P0
#define KEY_MATRIX_PORE		P1




void delay_10us(u16 us);
u8 key_matrix_ranks_scan(void);	//行列式扫描
u8 key_matrix_flip_scan(void);//翻转扫描法


/*************

左哥写的矩阵键盘

*************/
u8 key_matrix_flip_scanPro(void);
u8 key_matrix_flip_change(u8 date);
#endif