#include "key.h"

void delay_10us(u16 us)
{
	while(us--);
}

u8 key_scan(u8 mode)	//mode=1：连续扫描 mode=0：单次扫描
{
	static u8 flag=1;
	if(mode)flag=1;
	if(flag==1&&(key1==0||key2==0||key3==0||key4==0))
	{delay_10us(2000);flag=0;		
		if(key1==0){
		while(mode==0&&(key1==0));delay_10us(2000); 
			return KEY1_PRESS;
		}
		else if(key2==0){
			while(mode==0&&(key2==0));delay_10us(2000); 
			return KEY2_PRESS;
		}	
		else if(key3==0){
			while(mode==0&&(key3==0));delay_10us(2000); 
			return KEY3_PRESS;
		}
		else if(key4==0)
		{
			while(mode==0&&(key4==0));delay_10us(2000); 
			return KEY4_PRESS;
		}			
	}else if(key1==1&&key2==1&&key3==1&&key4==1){
		flag=1;
	}
	return KEY_UNPRESS;
}